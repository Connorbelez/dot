for i in range(10):
    print(i)


i = 1
while i < 10:
    i += 1


def func(d):
    print(d)
    func(d)
    if d > 10:
        print(d)

    G = 10
    g = 10
    print(g)

    print(G)


m = {"s": 10}
m["s"]

# print("adsf")


func("d")


class MyClass:
    def __init__(self, val, var) -> None:
        self.node = val


f = MyClass
