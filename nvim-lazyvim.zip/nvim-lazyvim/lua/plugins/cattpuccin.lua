return {
  {
    "catppuccin/nvim",
    lazy = false,
    name = "catppuccin",
    background = { dark = "mocha" },
    transparent_background = true,
    transparent = true,
    --  comment Test
    opts = {
      integrations = {
        aerial = true,
        alpha = true,
        cmp = true,
        dashboard = true,
        flash = true,
        gitsigns = true,
        headlines = true,
        illuminate = true,
        indent_blankline = { enabled = true },
        leap = true,
        lsp_trouble = true,
        mason = true,
        markdown = true,
        mini = true,
        native_lsp = {
          enabled = true,
          underlines = {
            errors = { "undercurl" },
            hints = { "undercurl" },
            warnings = { "undercurl" },
            information = { "undercurl" },
          },
        },
        navic = { enabled = true, custom_bg = "lualine" },
        neotest = true,
        neotree = true,
        noice = true,
        notify = true,
        semantic_tokens = true,
        telescope = true,
        treesitter = true,
        treesitter_context = true,
        which_key = true,
      },
    },
  },
  -- Configure LazyVim to load gruvbox

  {
    "LazyVim/LazyVim",

    opts = {
      colorscheme = "catppuccin",
    },
  },

  require("catppuccin").setup({
    custom_highlights = function(colors)
      return {
        ["@punctuation.bracket"] = { fg = "#46D9FF" },
        ["@punctuation.delimiter"] = { fg = "#ff6c6b" },
        Function = { fg = "#50fa7b" },
        ["@keyword"] = { fg = "#ff86d3" },
        ["@keyword.function"] = { fg = "#ff86d3" },
        ["@keyword.conditional"] = { fg = "#ff86d3" },
        ["@function.builtin"] = { fg = "#66c4ff" },
        ["@keyword.repeat"] = { fg = "#8BE9FD" },
        ["@keyword.operator"] = { fg = "#ff86d3" },
        ["@variable.member"] = { fg = "#c197fd" },
        ["@variable.parameter"] = { fg = "#c197fd" },
        Operator = { fg = "#ff6c6b" },

        -- Type = {fg = }
        -- Comment = { fg = colors.flamingo },
        -- TabLineSel = { bg = colors.pink },
        -- CmpBorder = { fg = colors.surface2 },
        Pmenu = { bg = colors.none },
      }
    end,
  }),
}
